//
//  HonorSheetView.swift
//  FinalProject
//
//  Created by Papou on 2025-04-14.
//

import SwiftUI

struct HonorSheetView: View {
    var match: Match
    @Environment(\.dismiss) var dismiss

    @State private var selectedTeammate: String = ""
    let teammates = ["Teammate A", "Teammate B", "Teammate C"]

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                Color.red.frame(height:10)

                VStack(spacing: 20) {
                    Text("Select a teammate to honor from your match:")
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)

                    Picker("Choose a teammate", selection: $selectedTeammate) {
                        ForEach(teammates, id: \.self) { teammate in
                            Text(teammate).tag(teammate)
                        }
                    }
                    .pickerStyle(.wheel)
                    .frame(height: 120)
                    .clipped()

                    Button(action: {
                        print("✅ Honored: \(selectedTeammate)")
                        dismiss()
                    }) {
                        Text("Submit Honor")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.yellow)
                            .foregroundColor(.black)
                            .cornerRadius(10)
                    }

                    Spacer()
                }
                .padding()
            }
            .navigationTitle("Honor a Teammate")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
