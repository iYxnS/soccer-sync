//
//  LeaderboardView.swift
//  FinalProject
//
//  Created by Papou on 2025-03-20.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct LeaderboardUser: Identifiable {
    let id: String
    let name: String
    let honorCount: Int
    let isCurrentUser: Bool
}

struct LeaderboardView: View {
    @State private var users: [LeaderboardUser] = []
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    Text("🏆 Leaderboard")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.yellow)
                        .padding(.top)

                    if users.isEmpty {
                        Text("No users yet.")
                            .foregroundColor(.gray)
                    } else {
                        ForEach(users.prefix(5).indices, id: \.self) { index in
                            let user = users[index]

                            HStack {
                                Text(rankIcon(for: index))
                                    .font(.title2)
                                    .frame(width: 30)

                                VStack(alignment: .leading) {
                                    Text(user.name + (user.isCurrentUser ? " (You)" : ""))
                                        .foregroundColor(.white)
                                        .fontWeight(user.isCurrentUser ? .bold : .regular)

                                    Text("\(user.honorCount) Honor\(user.honorCount == 1 ? "" : "s")")
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                }

                                Spacer()
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(10)
                            .padding(.horizontal)
                        }
                    }
                }
            }

            if let error = errorMessage {
                VStack {
                    Spacer()
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                }
            }
        }
        .onAppear {
            fetchLeaderboard()
        }
    }

    func rankIcon(for index: Int) -> String {
        switch index {
        case 0: return "🥇"
        case 1: return "🥈"
        case 2: return "🥉"
        default: return "\(index + 1)."
        }
    }

    func fetchLeaderboard() {
        guard let currentUID = Auth.auth().currentUser?.uid else { return }

        Firestore.firestore().collection("users")
            .order(by: "honorCount", descending: true)
            .getDocuments { snapshot, error in
                if let error = error {
                    self.errorMessage = "Error loading leaderboard: \(error.localizedDescription)"
                    return
                }

                self.users = snapshot?.documents.compactMap { doc in
                    let data = doc.data()
                    let firstName = data["firstName"] as? String ?? ""
                    let lastName = data["lastName"] as? String ?? ""
                    let honorCount = data["honorCount"] as? Int ?? 0
                    let uid = doc.documentID

                    return LeaderboardUser(
                        id: uid,
                        name: "\(firstName) \(lastName)",
                        honorCount: honorCount,
                        isCurrentUser: uid == currentUID
                    )
                } ?? []
            }
    }
}

struct LeaderboardView_Previews: PreviewProvider {
    static var previews: some View {
        LeaderboardView()
    }
}
