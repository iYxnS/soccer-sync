//
//  EditProfileView.swift
//  FinalProject
//
//  Created by Papou on 2025-04-12.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct EditProfileView: View {
    @Environment(\.dismiss) var dismiss

    var userProfile: UserProfile

    @State private var firstName: String
    @State private var lastName: String
    @State private var age: String
    @State private var position: String
    @State private var errorMessage: String?

    let positions = ["Goalkeeper", "Defender", "Midfielder", "Forward"]

    init(userProfile: UserProfile) {
        self.userProfile = userProfile
        _firstName = State(initialValue: userProfile.firstName)
        _lastName = State(initialValue: userProfile.lastName)
        _age = State(initialValue: userProfile.age)
        _position = State(initialValue: userProfile.position)
    }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Personal Info")) {
                    TextField("First Name", text: $firstName)
                    TextField("Last Name", text: $lastName)
                    TextField("Age", text: $age)
                        .keyboardType(.numberPad)

                    Picker("Position", selection: $position) {
                        ForEach(positions, id: \.self) { pos in
                            Text(pos)
                        }
                    }
                }

                if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .font(.footnote)
                }
            }
            .navigationTitle("Edit Profile")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save", action: saveProfile)
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel", action: { dismiss() })
                }
            }
        }
    }

    func saveProfile() {
        guard let uid = Auth.auth().currentUser?.uid else { return }

        let db = Firestore.firestore()
        db.collection("users").document(uid).updateData([
            "firstName": firstName,
            "lastName": lastName,
            "age": age,
            "position": position
        ]) { error in
            if let error = error {
                self.errorMessage = error.localizedDescription
            } else {
                dismiss()
            }
        }
    }
}

