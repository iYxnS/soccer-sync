//
//  ProfileView.swift
//  FinalProject
//
//  Created by Papou on 2025-03-20.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct UserProfile: Identifiable {
    let id: String
    let firstName: String
    let lastName: String
    let email: String
    let age: String
    let position: String
}

struct ProfileView: View {
    @Binding var isLoggedIn: Bool
    @State private var userProfile: UserProfile?
    @State private var errorMessage: String?
    @State private var showEditProfile = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if let user = userProfile {
                VStack(spacing: 30) {
                    VStack(spacing: 8) {
                        Image("soccersyncLogo")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                            .shadow(radius: 5)

                        Text("\(user.firstName) \(user.lastName)")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)

                        Button("Edit Profile") {
                            showEditProfile = true
                        }
                        .font(.headline)
                        .foregroundColor(.blue)
                        .padding(.top, 10)
                    }
                    .sheet(isPresented: $showEditProfile) {
                        EditProfileView(userProfile: user)
                    }

                    VStack(spacing: 16) {
                        profileItem(label: "📧 Email", value: user.email)
                        profileItem(label: "🎯 Position", value: user.position)
                        profileItem(label: "🎂 Age", value: user.age)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white.opacity(0.05))
                    .cornerRadius(20)
                    .padding(.horizontal, 30)

                    Spacer()

                    Button(action: logout) {
                        Text("Logout")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal, 30)
                    .padding(.bottom, 40)
                }
            } else if let error = errorMessage {
                Text("⚠️ \(error)")
                    .foregroundColor(.red)
            } else {
                ProgressView("Loading...")
                    .foregroundColor(.white)
            }
        }
        .onAppear(perform: loadUserProfile)
    }

    func profileItem(label: String, value: String) -> some View {
        HStack {
            Text(label)
                .foregroundColor(.white)
                .fontWeight(.semibold)
            Spacer()
            Text(value)
                .foregroundColor(.gray)
        }
        .padding(.vertical, 5)
    }

    func loadUserProfile() {
        guard let uid = Auth.auth().currentUser?.uid else {
            self.errorMessage = "No logged-in user found."
            return
        }

        let db = Firestore.firestore()
        db.collection("users").document(uid).getDocument { document, error in
            if let error = error {
                self.errorMessage = "Error loading profile: \(error.localizedDescription)"
                return
            }

            if let data = document?.data() {
                self.userProfile = UserProfile(
                    id: uid,
                    firstName: data["firstName"] as? String ?? "",
                    lastName: data["lastName"] as? String ?? "",
                    email: data["email"] as? String ?? "",
                    age: data["age"] as? String ?? "",
                    position: data["position"] as? String ?? ""
                )
            } else {
                self.errorMessage = "User data not found."
            }
        }
    }

    func logout() {
        do {
            try Auth.auth().signOut()
            isLoggedIn = false
        } catch {
            errorMessage = "Logout failed: \(error.localizedDescription)"
        }
    }
}



struct ProfileView_Previews: PreviewProvider {
    @State static var isLoggedIn = true

    static var previews: some View {
        ProfileView(isLoggedIn: $isLoggedIn)
    }
}
