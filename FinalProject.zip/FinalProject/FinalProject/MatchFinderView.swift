//
//  MatchFinderView.swift
//  FinalProject
//
//  Created by Papou on 2025-03-21.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import FirebaseFirestoreSwift

struct MatchFinderView: View {
    @State private var matches: [Match] = []
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    ForEach(matches) { match in
                        VStack(alignment: .leading, spacing: 10) {
                            Image(match.image)
                                .resizable()
                                .scaledToFill()
                                .frame(height: 150)
                                .clipped()
                                .cornerRadius(10)

                            Text(match.location)
                                .font(.headline)
                                .foregroundColor(.white)

                            Text("Type: \(match.type)")
                                .foregroundColor(.white.opacity(0.7))

                            Text("Date: \(formattedDate(match.date))")
                                .foregroundColor(.white.opacity(0.6))

                            if match.participants.contains(Auth.auth().currentUser?.uid ?? "") {
                                Button(action: {
                                    leaveMatch(match)
                                }) {
                                    Text("Cancel")
                                        .fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.red)
                                        .foregroundColor(.white)
                                        .cornerRadius(10)
                                }
                            } else {
                                Button(action: {
                                    joinMatch(match)
                                }) {
                                    Text("Join Match")
                                        .fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.yellow)
                                        .foregroundColor(.black)
                                        .cornerRadius(10)
                                }
                            }
                        }
                        .padding()
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    }
                }
                .padding(.top)
            }

            if let error = errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear(perform: fetchMatches)
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    func fetchMatches() {
        Firestore.firestore().collection("matches")
            .order(by: "date")
            .getDocuments { snapshot, error in
                if let error = error {
                    self.errorMessage = "Failed to fetch matches: \(error.localizedDescription)"
                    return
                }

                self.matches = snapshot?.documents.compactMap { doc in
                    try? doc.data(as: Match.self)
                } ?? []
            }
    }

    func joinMatch(_ match: Match) {
        guard let uid = Auth.auth().currentUser?.uid,
              let matchID = match.id else { return }

        let matchRef = Firestore.firestore().collection("matches").document(matchID)

        matchRef.updateData([
            "participants": FieldValue.arrayUnion([uid])
        ]) { error in
            if let error = error {
                self.errorMessage = "Join failed: \(error.localizedDescription)"
            } else {
                print("✅ Joined match \(matchID)")
                NotificationCenter.default.post(name: Notification.Name("MatchJoinedOrLeft"), object: nil)
                fetchMatches()
            }
        }
    }

    func leaveMatch(_ match: Match) {
        guard let uid = Auth.auth().currentUser?.uid,
              let matchID = match.id else { return }

        let matchRef = Firestore.firestore().collection("matches").document(matchID)

        matchRef.updateData([
            "participants": FieldValue.arrayRemove([uid])
        ]) { error in
            if let error = error {
                self.errorMessage = "Cancel failed: \(error.localizedDescription)"
            } else {
                print("❌ Left match \(matchID)")
                NotificationCenter.default.post(name: Notification.Name("MatchJoinedOrLeft"), object: nil)
                fetchMatches()
            }
        }
    }
}

struct MatchFinderView_Previews: PreviewProvider {
    static var previews: some View {
        MatchFinderView()
    }
}
