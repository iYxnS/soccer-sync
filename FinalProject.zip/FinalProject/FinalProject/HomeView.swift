//
//  HomeView.swift
//  FinalProject
//
//  Created by Papou on 2025-03-20.
//


import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import FirebaseFirestoreSwift

struct Match: Identifiable, Codable {
    @DocumentID var id: String?
    var date: Date
    var location: String
    var type: String
    var image: String
    var participants: [String]
}

struct HomeView: View {
    @Binding var isLoggedIn : Bool
    @State private var firstName: String = ""
    @State private var joinedMatches: [Match] = []
    @State private var errorMessage: String?
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {
                        ZStack(alignment: .bottomLeading) {
                            Rectangle()
                                .fill(LinearGradient(gradient: Gradient(colors: [Color.yellow.opacity(0.8), Color.black]), startPoint: .top, endPoint: .bottom))
                                .frame(height: 180)

                            VStack(alignment: .leading, spacing: 5) {
                                Text("Welcome Back,")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white.opacity(0.7))

                                Text(firstName.isEmpty ? "..." : firstName)
                                    .font(.largeTitle)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, 20)
                            .padding(.bottom, 15)
                        }
                        VStack(spacing: 15) {
                            NavigationLink(destination: MatchFinderView()) {
                                Text("⚽ Find a Match")
                                    .fontWeight(.bold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.yellow)
                                    .foregroundColor(.black)
                                    .cornerRadius(10)
                            }

                            NavigationLink(destination: LeaderboardView()) {
                                Text("🏆 View Leaderboard")
                                    .fontWeight(.bold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.white.opacity(0.2))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                            
                            NavigationLink(destination: GamesPlayedView()) {
                                Text("🎮 Games Played")
                                    .fontWeight(.bold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.white.opacity(0.2))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }

                            NavigationLink(destination: WorkoutView()) {
                                Text("💪 Go to Workout")
                                    .fontWeight(.bold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.white.opacity(0.2))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }

                            NavigationLink(destination: ProfileView(isLoggedIn: $isLoggedIn)) {
                                Text("👤 My Profile")
                                    .fontWeight(.bold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.white.opacity(0.2))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                        }
                        .padding(.horizontal, 30)

                        VStack(alignment: .leading, spacing: 10) {
                            Text("Upcoming Matches")
                                .font(.headline)
                                .foregroundColor(Color.white)
                                .padding(.horizontal, 20)

                            if joinedMatches.isEmpty {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.white.opacity(0.1))
                                    .frame(height: 80)
                                    .shadow(radius: 2)
                                    .overlay(
                                        Text("No upcoming matches yet")
                                            .foregroundColor(.gray)
                                            .italic()
                                    )
                                    .padding(.horizontal, 20)
                            } else {
                                ForEach(joinedMatches) { match in
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color.white.opacity(0.1))
                                        .frame(height: 100)
                                        .shadow(radius: 2)
                                        .overlay(
                                            VStack(alignment: .leading, spacing: 4) {
                                                Text(match.location)
                                                    .font(.headline)
                                                    .foregroundColor(.white)
                                                Text("Type: \(match.type)")
                                                    .foregroundColor(.white.opacity(0.7))
                                                Text("Date: \(formattedDate(match.date))")
                                                    .foregroundColor(.white.opacity(0.6))
                                            }
                                            .padding()
                                        )
                                        .padding(.horizontal, 20)
                                }
                            }
                        }
                        .padding(.top, 20)

                        Spacer()
                    }
                }
            }
        }
        .onAppear {
            fetchUserName()
            fetchJoinedMatches()
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("MatchJoinedOrLeft"))) { _ in
            fetchJoinedMatches()
        }
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    func fetchUserName() {
        guard let uid = Auth.auth().currentUser?.uid else { return }

        Firestore.firestore().collection("users").document(uid).getDocument { doc, error in
            if let data = doc?.data(), let fname = data["firstName"] as? String {
                self.firstName = fname
            }
        }
    }

    func fetchJoinedMatches() {
        guard let uid = Auth.auth().currentUser?.uid else { return }

        Firestore.firestore().collection("matches")
            .whereField("participants", arrayContains: uid)
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Failed to fetch joined matches: \(error.localizedDescription)")
                    return
                }

                self.joinedMatches = snapshot?.documents.compactMap { doc in
                    try? doc.data(as: Match.self)
                }.sorted(by: { $0.date < $1.date }) ?? []
            }
    }
}



struct HomeView_Previews: PreviewProvider {
    @State static var isLoggedIn = true

    static var previews: some View {
        HomeView(isLoggedIn: $isLoggedIn)
    }
}
