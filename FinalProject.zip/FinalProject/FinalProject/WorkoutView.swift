//
//  WorkoutView.swift
//  FinalProject
//
//  Created by Papou on 2025-03-21.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct WorkoutView: View {
    struct Workout: Identifiable {
        let id = UUID()
        let title: String
        let description: String
        let icon: String
    }

    let workouts: [Workout] = [
        .init(title: "Speed & Agility", description: "Short sprints, cone drills, quick feet", icon: "⚡"),
        .init(title: "Dribbling Skills", description: "Cone weaving, tight ball control", icon: "⚽"),
        .init(title: "Conditioning", description: "Endurance runs, interval training", icon: "🔥"),
        .init(title: "Strength & Core", description: "Bodyweight, resistance training", icon: "💪")
    ]

    struct CompletedWorkout: Identifiable {
        let id: String
        let type: String
        let date: Date
    }

    @State private var completedThisWeek: Int = 0
    @State private var recentWorkouts: [CompletedWorkout] = []
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    Text("Workout")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.yellow)
                        .padding(.top)

                    Text("You’ve completed \(completedThisWeek) workout(s) this week")
                        .foregroundColor(.white.opacity(0.8))
                        .font(.subheadline)

                    ForEach(workouts) { workout in
                        VStack(alignment: .leading, spacing: 8) {
                            Text("\(workout.icon) \(workout.title)")
                                .font(.headline)
                                .foregroundColor(.white)

                            Text(workout.description)
                                .font(.subheadline)
                                .foregroundColor(.gray)

                            Button(action: {
                                logWorkout(type: workout.title)
                            }) {
                                Text("Mark as Completed")
                                    .fontWeight(.bold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.yellow)
                                    .foregroundColor(.black)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(12)
                        .padding(.horizontal)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Recent Workouts")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding(.horizontal)

                        if recentWorkouts.isEmpty {
                            Text("No workouts logged yet.")
                                .foregroundColor(.gray)
                                .padding(.horizontal)
                        } else {
                            ForEach(recentWorkouts.prefix(5)) { workout in
                                Text("• \(workout.type) – \(formattedDate(workout.date))")
                                    .foregroundColor(.white.opacity(0.8))
                                    .padding(.horizontal)
                            }
                        }
                    }
                    .padding(.top)
                }
            }

            if let error = errorMessage {
                VStack {
                    Spacer()
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                }
            }
        }
        .onAppear {
            fetchWorkoutSummary()
        }
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    func logWorkout(type: String) {
        guard let uid = Auth.auth().currentUser?.uid else { return }

        let db = Firestore.firestore()
        db.collection("workouts").addDocument(data: [
            "userID": uid,
            "type": type,
            "timestamp": Date()
        ]) { error in
            if let error = error {
                self.errorMessage = "Error saving workout: \(error.localizedDescription)"
            } else {
                print("✅ Workout logged")
                fetchWorkoutSummary()
            }
        }
    }

    func fetchWorkoutSummary() {
        guard let uid = Auth.auth().currentUser?.uid else { return }

        Firestore.firestore().collection("workouts")
            .whereField("userID", isEqualTo: uid)
            .getDocuments { snapshot, error in
                if let error = error {
                    self.errorMessage = "Error loading workouts: \(error.localizedDescription)"
                    return
                }

                let documents = snapshot?.documents ?? []
                let allWorkouts = documents.compactMap { doc -> CompletedWorkout? in
                    let data = doc.data()
                    guard let type = data["type"] as? String,
                          let timestamp = data["timestamp"] as? Timestamp else { return nil }

                    return CompletedWorkout(id: doc.documentID, type: type, date: timestamp.dateValue())
                }

                let calendar = Calendar.current
                let startOfWeek = calendar.date(from: calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date()))!

                self.completedThisWeek = allWorkouts.filter { $0.date >= startOfWeek }.count
                self.recentWorkouts = allWorkouts.sorted(by: { $0.date > $1.date })
            }
    }
}
struct WorkoutView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutView()
    }
}
