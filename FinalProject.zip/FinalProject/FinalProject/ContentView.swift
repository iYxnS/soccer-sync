//
//  ContentView.swift
//  FinalProject
//
//  Created by Papou on 2025-03-19.
//

import SwiftUI
import FirebaseAuth

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String?
    @State private var isLoggedIn = false
    @State private var showSignUp = false

    var body: some View {
        if isLoggedIn {
            HomeView(isLoggedIn: $isLoggedIn)
        } else {
            ZStack {
                Color.black.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {
                        Image("soccersyncLogo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 100)
                            .padding(.top, 60)

                        Text("SoccerSync")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.yellow)

                        Group {
                            TextField("Email", text: $email)
                                .autocapitalization(.none)
                                .padding()
                                .background(Color.white.opacity(0.1))
                                .cornerRadius(10)
                                .foregroundColor(.white)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.3)))
                                .padding(.horizontal, 30)

                            SecureField("Password", text: $password)
                                .padding()
                                .background(Color.white.opacity(0.1))
                                .cornerRadius(10)
                                .foregroundColor(.white)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.3)))
                                .padding(.horizontal, 30)
                        }

                        Button(action: loginUser) {
                            Text("Login")
                                .fontWeight(.bold)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.yellow)
                                .foregroundColor(.black)
                                .cornerRadius(10)
                        }
                        .padding(.horizontal, 30)
                        .padding(.top, 10)

                        if let errorMessage = errorMessage {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.footnote)
                                .padding(.top, 5)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }

                        Button("Don't have an account? Sign up") {
                            showSignUp = true
                        }
                        .foregroundColor(.yellow)
                        .font(.footnote)
                        .padding(.top, 10)
                        .sheet(isPresented: $showSignUp) {
                            SignUpView()
                        }

                        Spacer()
                    }
                }
            }
        }
    }

    func loginUser() {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                self.errorMessage = error.localizedDescription
            } else {
                print("✅ Logged in successfully.")
                self.isLoggedIn = true
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
