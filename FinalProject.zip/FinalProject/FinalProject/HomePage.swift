//
//  HomePage.swift
//  FinalProject
//
//  Created by Papou on 2025-03-20.
//

import SwiftUI

struct HomePage: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
