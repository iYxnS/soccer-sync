//
//  SignUpView.swift
//  FinalProject
//
//  Created by Papou on 2025-03-20.
//

import FirebaseFirestore
import SwiftUI
import FirebaseAuth
import FirebaseCore

struct SignUpView: View {
    @Environment(\.dismiss) var dismiss

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var age = ""
    @State private var selectedPosition = "Select Position"
    @State private var acceptTerms = false
    @State private var errorMessage: String?
    @State private var isSignedUp = false

    let positions = ["Goalkeeper", "Defender", "Midfielder", "Forward"]

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()

            VStack(spacing: 20) {
                VStack(spacing: 5) {
                    Text("Sign Up")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)

                    Text("Please fill in this form to create an account!")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .padding(.top, 30)

                HStack(spacing: 10) {
                    TextField("First Name", text: $firstName)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)

                    TextField("Last Name", text: $lastName)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                }
                .padding(.horizontal, 30)

                TextField("Email", text: $email)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal, 30)

                SecureField("Password", text: $password)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal, 30)

                SecureField("Confirm Password", text: $confirmPassword)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal, 30)

                TextField("Age", text: $age)
                    .keyboardType(.numberPad)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal, 30)

                Menu {
                    ForEach(positions, id: \.self) { position in
                        Button(action: { selectedPosition = position }) {
                            Text(position)
                        }
                    }
                } label: {
                    HStack {
                        Text(selectedPosition)
                            .foregroundColor(selectedPosition == "Select Position" ? .gray : .black)
                        Spacer()
                        Image(systemName: "chevron.down")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal, 30)
                }

                HStack {
                    Button(action: { acceptTerms.toggle() }) {
                        Image(systemName: acceptTerms ? "checkmark.square.fill" : "square")
                            .foregroundColor(acceptTerms ? .blue : .gray)
                    }

                    Text("I accept the ")
                        .foregroundColor(.black)

                    Text("Terms of Use & Privacy Policy")
                        .foregroundColor(.blue)
                        .underline()
                }
                .font(.footnote)
                .padding(.horizontal, 30)

                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.footnote)
                        .padding(.horizontal)
                }

                Button(action: signUp) {
                    Text("Sign Up")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.horizontal, 30)
                .padding(.top, 10)
            }
        }
    }

    func signUp() {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "Email and password are required."
            return
        }

        guard password == confirmPassword else {
            errorMessage = "Passwords do not match."
            return
        }

        guard acceptTerms else {
            errorMessage = "You must accept the terms."
            return
        }

        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                print("🔥 Firebase Auth Error:", error.localizedDescription)
                self.errorMessage = error.localizedDescription
            } else if let user = result?.user {
                let db = Firestore.firestore()
                db.collection("users").document(user.uid).setData([
                    "uid": user.uid,
                    "email": user.email ?? "",
                    "firstName": firstName,
                    "lastName": lastName,
                    "age": age,
                    "position": selectedPosition,
                    "createdAt": Timestamp()
                ]) { err in
                    if let err = err {
                        print("🔥 Firestore Error:", err.localizedDescription) 
                        self.errorMessage = "Firestore error: \(err.localizedDescription)"
                    } else {
                        print("✅ User data saved to Firestore.")
                        self.isSignedUp = true
                        dismiss()
                    }
                }
            }
        }
    }
}
    
struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
