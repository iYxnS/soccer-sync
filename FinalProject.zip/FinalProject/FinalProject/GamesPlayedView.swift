//
//  GamesPlayedView.swift
//  FinalProject
//
//  Created by Papou on 2025-04-14.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import FirebaseFirestoreSwift

struct GamesPlayedView: View {
    @State private var completedMatches: [Match] = []

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    Text("Games Played")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.yellow)
                        .padding(.top)

                    if completedMatches.isEmpty {
                        Text("No games played yet.")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        ForEach(completedMatches) { match in
                            VStack(alignment: .leading, spacing: 10) {
                                Image(match.image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: 150)
                                    .clipped()
                                    .cornerRadius(10)

                                Text(match.location)
                                    .font(.headline)
                                    .foregroundColor(.white)

                                Text("Type: \(match.type)")
                                    .foregroundColor(.white.opacity(0.7))

                                Text("Date: \(formattedDate(match.date))")
                                    .foregroundColor(.white.opacity(0.6))

                                Button(action: {}) {
                                    Text("Honor a Teammate (Coming Soon)")
                                        .fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.gray.opacity(0.3))
                                        .foregroundColor(.white.opacity(0.6))
                                        .cornerRadius(10)
                                }
                                .disabled(true)
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                        }
                    }
                }
            }
        }
        .onAppear {
            fetchCompletedMatches()
        }
    }

    func fetchCompletedMatches() {
        guard let uid = Auth.auth().currentUser?.uid else { return }

        Firestore.firestore().collection("matches")
            .whereField("participants", arrayContains: uid)
            .whereField("status", isEqualTo: "completed")
            .getDocuments { snapshot, error in
                if let docs = snapshot?.documents {
                    self.completedMatches = docs.compactMap { doc in
                        try? doc.data(as: Match.self)
                    }.sorted(by: { $0.date > $1.date })
                }
            }
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
struct GamesPlayedView_Previews: PreviewProvider {
    static var previews: some View {
        GamesPlayedView()
    }
}
